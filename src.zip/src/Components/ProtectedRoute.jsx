import { useQuery } from "@tanstack/react-query";
import { Navigate, useLocation } from "react-router-dom";
import Spinner from "./Spinner";
import { fetchCurrentUser } from "../services/authProvider";
import { useContext, useEffect } from "react";
import { Homecontext } from "../Context/LoginContext";

export default function ProtectedRoute({ children }) {
  const { homepass } = useContext(Homecontext);
  const location = useLocation();

  const {
    data: user,
    isPending,
    refetch,
  } = useQuery({
    queryKey: ["user"],
    queryFn: fetchCurrentUser,
    refetchOnWindowFocus: false,
    staleTime: 5 * 60 * 1000,
    retry: false,
  });

  useEffect(() => {
    refetch();
  }, [location]);

  if (isPending) return <Spinner />;
  if (!homepass) return <Navigate to="/home" replace />;
  if (!user) return <Navigate to="/login" replace />;

  return <div>{children}</div>;
}
